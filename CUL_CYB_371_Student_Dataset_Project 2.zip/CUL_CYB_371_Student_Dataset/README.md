# CUL-CYB 371 – Data Mining and Data Warehousing

## Project: Fictional Student Dataset

This project contains a fictional dataset of 30 students. It was created with Python and saved in CSV format.

### Dataset fields
1. Student ID
2. Department
3. Level
4. Attendance Percentage
5. Average Examination Score

### Files
- `student_dataset.csv` — the completed dataset.
- `generate_dataset.py` — Python program used to create the dataset.

### How to run
Make sure Python 3 is installed. Open a terminal in this project folder and run:

```bash
python generate_dataset.py
```

The program creates (or replaces) `student_dataset.csv` in the current folder.

### Note
All student records and scores in this project are fictional and are for academic practice only.
