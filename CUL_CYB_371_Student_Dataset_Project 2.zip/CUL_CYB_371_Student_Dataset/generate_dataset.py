"""
CUL-CYB 371: Data Mining and Data Warehousing
Creates a fictional student dataset and saves it as student_dataset.csv.
Run with: python generate_dataset.py
"""
import csv

students = [
    ("STU001", "Computer Science", 300, 92, 84),
    ("STU002", "Cyber Security", 200, 88, 79),
    ("STU003", "Information Technology", 100, 76, 68),
    ("STU004", "Software Engineering", 400, 95, 91),
    ("STU005", "Computer Science", 200, 81, 73),
    ("STU006", "Cyber Security", 300, 90, 86),
    ("STU007", "Information Technology", 400, 84, 77),
    ("STU008", "Software Engineering", 100, 72, 65),
    ("STU009", "Computer Science", 400, 97, 93),
    ("STU010", "Cyber Security", 100, 69, 61),
    ("STU011", "Information Technology", 200, 87, 82),
    ("STU012", "Software Engineering", 300, 91, 88),
    ("STU013", "Computer Science", 100, 78, 70),
    ("STU014", "Cyber Security", 400, 94, 89),
    ("STU015", "Information Technology", 300, 83, 75),
    ("STU016", "Software Engineering", 200, 89, 81),
    ("STU017", "Computer Science", 300, 85, 78),
    ("STU018", "Cyber Security", 200, 74, 67),
    ("STU019", "Information Technology", 100, 93, 90),
    ("STU020", "Software Engineering", 400, 80, 74),
    ("STU021", "Computer Science", 200, 67, 59),
    ("STU022", "Cyber Security", 300, 86, 80),
    ("STU023", "Information Technology", 400, 96, 92),
    ("STU024", "Software Engineering", 100, 77, 69),
    ("STU025", "Computer Science", 400, 89, 85),
    ("STU026", "Cyber Security", 100, 82, 76),
    ("STU027", "Information Technology", 200, 71, 64),
    ("STU028", "Software Engineering", 300, 98, 95),
    ("STU029", "Computer Science", 100, 88, 83),
    ("STU030", "Cyber Security", 400, 79, 72),
]

columns = [
    "Student ID",
    "Department",
    "Level",
    "Attendance Percentage",
    "Average Examination Score",
]

with open("student_dataset.csv", "w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(columns)
    writer.writerows(students)

print(f"Dataset created successfully: {len(students)} fictional student records.")
